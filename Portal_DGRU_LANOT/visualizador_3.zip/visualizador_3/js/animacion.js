// example.js

//var t = [0,1.,2.,3.,4.,5.];
//var t = ' 2006-1-1 00:00:00,2006-1-3 01:00:00,2006-1-6 00:00:00'
//var t ='2006-01/2007-01/P1M'

//var eventoAnimacion = L.layerGroup();
//var eventoTrayectoria = L.layerGroup();
(function (window) {'use strict';
    function initMap() {
        var control;
        var L = window.L;

        var map = L.map('map', {
            zoom: 5,
            zoominfoControl: true,
            zoomControl: false,
            fullscreenControl: true,
            fullscreenControlOptions: {
            position: 'topleft'
            },
            loadingControl: true,
            loadingControlOptions: {
            position: 'bottomleft'
            },
            timeDimension: true,
            timeDimensionOptions:{
                //times : t,
                timeInterval: "2017-09-05 00:00:00/2017-09-09 00:00:00",
                period: "PT1H",
            },
            timeDimensionControl: true,
            timeDimensionControlOptions:{
                position: "bottomcenter",
                autoPlay: false,       
                loopButton: true,
                limitSliders: true,
                timeSliderDragUpdate: true,
                playReverseButton: false,
                playerOptions: {            
                    loop: true,
                    transitionTime:1000,
                }       
                //timeSteps: 1,
            },    
            condensedAttributionControl: false,
            center: [19.9,-99.0],
            //layers: [mbGrayscale,eventoAnimacion]
        });

        /*
        L.control.zoom({
            position: 'topleft'
        }).addTo(map);
        */



        L.control.zoomBox({
        modal: true,
        title: "Box area zoom",
        position: 'topleft_1',
        }).addTo(map);

        L.control.navbar({
            position:"topleft_1",
        }).addTo(map);


        //Initialize the StyleEditor
	    var styleEditor = L.control.styleEditor({
	        position: "topleft_1",
	        useGrouping: false,
	        openOnLeafletDraw: true,
	    });
	    map.addControl(styleEditor);




        /*
        var miniMap = new L.Control.GlobeMiniMap({     
          land:'#FFFFFF',
          water:'#1fa4f1',
          marker:'#000000',
          topojsonSrc: 'data/world.json'
        }).addTo(map);
        */

        // TILES LAYERS
        var mbAttr = 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors,<a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>,Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
            mbUrl = 'https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token=pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpejY4NXVycTA2emYycXBndHRqcmZ3N3gifQ.rJcFIG214AriISLbB6B5aw',
            
            esri_wiAttr = 'Tiles &copy; Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community',
            esri_wiUrl = 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',

            esri_OceanAttr = 'Tiles &copy; Esri &mdash; Sources: GEBCO, NOAA, CHS, OSU, UNH, CSUMB, National Geographic, DeLorme, NAVTEQ, and Esri',
            esri_OceanUrl = 'https://server.arcgisonline.com/ArcGIS/rest/services/Ocean_Basemap/MapServer/tile/{z}/{y}/{x}' ,

            openStreetMapAttr = '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
            openStreetMapUrl = 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',

            stamenTerrainAttr = 'Map tiles by <a href="http://stamen.com">Stamen Design</a>, <a href="http://creativecommons.org/licenses/by/3.0">CC BY 3.0</a> &mdash; Map data &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
            stamenTerrainUrl = 'https://stamen-tiles-{s}.a.ssl.fastly.net/terrain/{z}/{x}/{y}{r}.{ext}',

            cartoDB_DarkAttr = '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>',
            cartoDB_DarkUrl = 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png',

            nasaGIBS_ViirsAttr = 'Imagery provided by services from the Global Imagery Browse Services (GIBS), operated by the NASA/GSFC/Earth Science Data and Information System (<a href="https://earthdata.nasa.gov">ESDIS</a>) with funding provided by NASA/HQ.',
            nasaGIBS_ViirsUrl = 'https://map1.vis.earthdata.nasa.gov/wmts-webmerc/VIIRS_CityLights_2012/default/{time}/{tilematrixset}{maxZoom}/{z}/{y}/{x}.{format}';


        var mbGrayscale   = L.tileLayer(mbUrl, {id: 'mapbox.light', attribution: mbAttr,edgeBufferTiles: 1,label:'MapBox Light'}),
            mbStreets  = L.tileLayer(mbUrl, {id: 'mapbox.streets',   attribution: mbAttr,edgeBufferTiles: 1,label:'MapBox Streets'}),
            esri_wi  = L.tileLayer(esri_wiUrl, {attribution: esri_wiAttr,edgeBufferTiles: 1,label:'ESRI World Imagery'}),
            esri_Ocean  = L.tileLayer(esri_OceanUrl, {attribution: esri_OceanAttr,edgeBufferTiles: 1,label:'ESRI Ocean'}),
            openStreetMap = L.tileLayer(openStreetMapUrl, {attribution: openStreetMapAttr,edgeBufferTiles: 1,label:'OpenStreetMap'}),
            stamenTerrain = L.tileLayer(stamenTerrainUrl, {subdomains:'abcd',ext:'png',attribution: stamenTerrainAttr,edgeBufferTiles: 1,label:'Stamen Terrain'}),
            cartoDB_Dark = L.tileLayer(cartoDB_DarkUrl, {subdomains:'abcd',attribution: cartoDB_DarkAttr,edgeBufferTiles: 1,label:'CartoDB Dark'}),
            nasaGIBS_Viirs = L.tileLayer(nasaGIBS_ViirsUrl, {bounds: [[-85.0511287776, -179.999999975], [85.0511287776, 179.999999975]],minZoom: 1,maxZoom: 8,format: 'jpg',time: '',tilematrixset: 'GoogleMapsCompatible_Level',edgeBufferTiles: 1,label:'NASA GIBS VIIRS CityLights 2012'});

        var basemaps = [
        esri_wi,
       //mbStreets,
        mbGrayscale,
        esri_Ocean,
        openStreetMap,
        //stamenTerrain,
        //cartoDB_Dark,
        nasaGIBS_Viirs,
        ];



        // set custom emblem and prefix
        L.control.condensedAttribution({
          emblem: '<div class="emblem-wrap"><img src="https://cdn3.iconfinder.com/data/icons/map-markers-1/512/information-512.png"/></div>',
          prefix: '<a href="https://www.route360.net/" title="Travel time analysis by Motion Intelligence">route360&deg;</a> | <a href="http://leafletjs.com" title="A JS library for interactive maps">Leaflet</a>',
          position: 'bottomright'
        }).addTo(map);


        // Basemaps control
        var controlBase = L.control.basemaps({
            position : 'bottomleft',
            basemaps: basemaps,
            tileX: 0,  // tile X coordinate
            tileY: 0,  // tile Y coordinate
            tileZ: 1   // tile zoom level
        }).addTo(map);

        
        // coordenadas 
        L.control.coordinates({
            position:"bottomright",
            decimals:2,
            decimalSeperator:".",
            labelTemplateLat:"Latitud: {y}",
            labelTemplateLng:"Longitud: {x}"
        }).addTo(map);

        // escala
        L.control.scale({
            position: 'bottomright'
        }).addTo(map);


  var miniMap = new L.Control.MiniMap(mbStreets, { toggleDisplay: true ,minimized: false, position:'bottomright'}).addTo(map);



        var proxy = 'server/proxy.php';
        var testWMS = "http://132.247.103.145:8080/geoserver/wms?SERVICE=WMS&"

        var testLayer = L.tileLayer.wms(testWMS, {
            layers: 'cite:katia',
            format: 'image/png',
            transparent: true,
            styles: document.getElementById('styles').value,     
            //attribution: '<a href="https://www.pik-potsdam.de/">PIK</a>'
        });
       

       
        var eventoTrayectoria  = L.tileLayer.wms(testWMS, {
            layers: 'cite:katia_trayectoria',
            format: 'image/png',
            transparent: true,            
            //attribution: '<a href="https://www.pik-potsdam.de/">PIK</a>'
        });



        var costa = L.tileLayer.wms(testWMS, {
            layers: 'cite:coastline_G16',
            format: 'image/png',
            transparent: true,
            //attribution: '<a href="https://www.pik-potsdam.de/">PIK</a>'
        });



        // VIDEO capa
        var bounds = L.latLngBounds([[6.29,-125.181], [34.782166,-78.92616]]);
        var videoUrls = ['http://132.247.103.186/animations/local/rgb/latest.mp4'];

 



        var eventoAnimacion = L.timeDimension.layer.wms(testLayer,{updateTimeDimension: true}, {proxy: proxy});
        //eventoAnimacion.addTo(map);

        //var eventoTrayectoria = L.timeDimension.layer.wms(testLayer_tra,{updateTimeDimension: true}, {proxy: proxy});
        //eventoTrayectoria.on('mouseover', function () {
          //  this.setText('  ►  ', {repeat: true, attributes: {fill: 'red'}});
        //});

        //eventoTrayectoria.on('mouseout', function () {
          //  this.setText(null);
        //});

        //eventoTrayectoria.addTo(map);

        costa.addTo(map)
        /*
        var testLegend = L.control({
            position: 'topright'
        });
        testLegend.onAdd = function(map) {
            var src = testWMS + "?SERVICE=WMS&VERSION=1.3.0&REQUEST=GetLegendGraphic&LAYER=tmp&PALETTE=tmp";
            var div = L.DomUtil.create('div', 'info legend');
            div.innerHTML +=
                '<img src="' + src + '" alt="legend">';
            return div;
        };
        testLegend.addTo(map);
        */



//VIDEO
///===============================================================
       var videoOverlay = L.videoOverlay( videoUrls, bounds, {

        });
//CONTROL VIDEO
///===============================================================
videoOverlay.on('load', function () {
        var MyPauseControl = L.Control.extend({
            onAdd: function() {
                var button = L.DomUtil.create('button');
                button.style.backgroundColor = '#1fa4f1';     
                button.style.backgroundImage = "url(data/imagenes/iconos/Pause-512.png)";
                button.style.backgroundSize = "25px 25px";
                button.style.width = '30px';
                button.style.height = '30px';
                button.style.border= "2px solid #FFFFFF";

                L.DomEvent.on(button, 'click', function () {
                    videoOverlay.getElement().pause();
                });
                return button;
            },

        });
        var MyPlayControl = L.Control.extend({
            onAdd: function() {
                var button = L.DomUtil.create('button');
                button.style.backgroundColor = '#1fa4f1';     
                button.style.backgroundImage = "url(data/imagenes/iconos/Play-512.png)";
                button.style.backgroundSize = "25px 25px";
                button.style.width = '30px';
                button.style.height = '30px';
                button.style.border= "2px solid #FFFFFF";
                L.DomEvent.on(button, 'click', function () {
                    videoOverlay.getElement().play();
                });
                return button;
            }
        });

        var playControl = (new MyPlayControl({ position: 'bottomcenter_1'})).addTo(map);
        var pauseControl = (new MyPauseControl({ position: 'bottomcenter_2'})).addTo(map);
 
    });

//VIDEO
///===============================================================

    var legendAnimacion = L.control.htmllegend({
        position: 'bottomright',
        legends: [{
            name: 'Katia',
            layer: eventoAnimacion,
            elements: [{
                label: 'Rectangle',
                html: '',
                style: {
                    'background-color': 'red',
                    'width': '10px',
                    'height': '10px'
                }
            }, {
                label: 'Triangle',
                html: '',
                style: {
                    'background-color': 'green',
                    'width': '10px',
                    'height': '10px'
                }
            }]
        }],
        collapseSimple: true,
        detectStretched: true,
        collapsedOnInit: true,
        defaultOpacity: 0.6,
        visibleIcon: 'icon icon-eye',
        hiddenIcon: 'icon icon-eye-slash'
    })
    map.addControl(legendAnimacion);

var legendTrayectoria = L.control.htmllegend({
        position: 'bottomright',
        legends: [{
            name: 'Katia Trayectoria',
            layer: eventoTrayectoria,
            elements: [{
                label: 'Rectangle',
                html: '',
                style: {
                    'background-color': 'red',
                    'width': '10px',
                    'height': '10px'
                }
            }, {
                label: 'Triangle',
                html: '',
                style: {
                    'background-color': 'green',
                    'width': '10px',
                    'height': '10px'
                }
            }]
        }],
        collapseSimple: true,
        detectStretched: true,
        collapsedOnInit: true,
        defaultOpacity: 0.6,
        visibleIcon: 'icon icon-eye',
        hiddenIcon: 'icon icon-eye-slash'
    })
    map.addControl(legendTrayectoria);

    var legendVideo= L.control.htmllegend({
        position: 'bottomright',
        legends: [{
            name: 'Katia Video',
            layer: videoOverlay,
                        elements: [{
                
            }]
        }],
        collapseSimple: true,
        detectStretched: true,
        collapsedOnInit: true,
        defaultOpacity: 0.6,
        visibleIcon: 'icon icon-eye',
        hiddenIcon: 'icon icon-eye-slash'
    })
    map.addControl(legendVideo);



        var logo= L.control({position : 'topright'});

        logo.onAdd = function(map) {
            this._div = L.DomUtil.create('div', 'myControl');
            var img_log = "<div><img src=\"data/imagenes/logos/logos_1.png\"></img></div>";

            this._div.innerHTML = img_log;
            return this._div;

        }
        logo.addTo(map);


        var titulo= L.control({position : 'topcenter'});

        titulo.onAdd = function(map) {
            this._div = L.DomUtil.create('div', 'myControl');
            var text = "<div class='titulo'><h5 class='call'> <font color='#FFFFFF'><center>Húracan <em>KATIA</em> categoria 5</center></font></h5><h8><font color='#FFFFFF'><center>08/09/2017 - 08/09/2017</center></font></h8></div>";

            this._div.innerHTML = text;
            return this._div;

        }
        titulo.addTo(map);
      

        var layers = {"Evento":{
                "Katia": eventoAnimacion},
                "Trayectoria":{
                "Trayectoria Katia": eventoTrayectoria},
                "Video": {
                    "Katia":videoOverlay},
                "Limites":{
                "Costa": costa}
        };

        var baseLayers = {
            
        };

   

   // control de capas
   /*  L.control.groupedLayers(baseLayers,layers,{
        position: 'topright'
  }).addTo(map);*/

        // rule
        L.control.ruler({
            position: 'topleft',
            circleMarker: {               // Leaflet circle marker options for points used in this plugin
                color: '#FFFFFF',
                radius: 2
            },
            lineStyle: {                  // Leaflet polyline options for lines used in this plugin
                color: '#1fa4f1',
                dashArray: '1,6'
            },
        }).addTo(map);



        var printer = L.easyPrint({
      		tileLayer: esri_wi,
      		sizeModes: ['Current', 'A4Landscape', 'A4Portrait'],
      		filename: 'myMap',
      		exportOnly: true,
      		hideControlContainer: true,
      		position:'topleft_1'
		}).addTo(map);

		function manualPrint () {
			printer.printMap('CurrentSize', 'MyManualPrint')
		}


        // add layer
        var style = {
                    color: 'red',
                    opacity: 1.0,
                    fillOpacity: 1.0,
                    weight: 2,
                    clickable: false
                };
           
        L.Control.FileLayerLoad.LABEL = '<img class="icon" src="data/imagenes/iconos/folder.svg" alt="file icon"/>';
                control = L.Control.fileLayerLoad({
                    fitBounds: true,
                    layerOptions: {
                        style: style,
                        pointToLayer: function (data, latlng) {
                            return L.circleMarker(
                                latlng,
                                { style: style }
                            );
                        }
                    }
                });
                control.addTo(map);
                control.loader.on('data:loaded', function (e) {
                    var layer = e.layer;
                    console.log(layer);
                });
            

        // create the geocoding control and add it to the map
        var searchControl = L.esri.Geocoding.geosearch({
            position:"topleft_2"
        }).addTo(map);

        // create an empty layer group to store the results and add it to the map
        var results = L.layerGroup().addTo(map);

        // listen for the results event and add every result to the map
        searchControl.on("results", function(data) {
            results.clearLayers();
            for (var i = data.results.length - 1; i >= 0; i--) {
                results.addLayer(L.marker(data.results[i].latlng));
            }
        });

         // create custom icon
        var firefoxIcon = L.icon({
            iconUrl: 'https://cdn.pixabay.com/photo/2015/12/09/22/19/hurricane-1085673_960_720.png',
            iconSize: [28, 25], // size of the icon
        });

        var sidebar = L.control.sidebar('sidebar', {
                    closeButton: true,
                    position: 'left'
                });
                map.addControl(sidebar);

                /*setTimeout(function () {
                    sidebar.show();
                }, 500);*/

                var popup = L.responsivePopup().setContent('KATIA');
                var marker = L.marker([20.061111,-97.688611],{
                    icon:firefoxIcon,
                }).bindPopup(popup).on('click', function () {
                    sidebar.toggle();
                });

                map.on('click', function () {
                    sidebar.hide();
                })

                sidebar.on('show', function () {
                    console.log('Sidebar will be visible.');
                });

                sidebar.on('shown', function () {
                    console.log('Sidebar is visible.');
                });

                sidebar.on('hide', function () {
                    console.log('Sidebar will be hidden.');
                });

                sidebar.on('hidden', function () {
                    console.log('Sidebar is hidden.');
                });

                L.DomEvent.on(sidebar.getCloseButton(), 'click', function () {
                    console.log('Close button clicked.');
                });

 // DRAW
//=================================================================================
	var drawnItems = L.featureGroup().addTo(map);

	 map.addControl(new L.Control.Draw({
        edit: {
            featureGroup: drawnItems,
            poly : {
                allowIntersection : false
            }
        },
        draw: {
            polygon : {
                allowIntersection: false,
                showArea:true
            }
        }
    }));

    // Truncate value based on number of decimals
    var _round = function(num, len) {
        return Math.round(num*(Math.pow(10, len)))/(Math.pow(10, len));
    };
    // Helper method to format LatLng object (x.xxxxxx, y.yyyyyy)
    var strLatLng = function(latlng) {
        return "("+_round(latlng.lat, 6)+", "+_round(latlng.lng, 6)+")";
    };

    // Generate popup content based on layer type
    // - Returns HTML string, or null if unknown object
    var getPopupContent = function(layer) {
        // Marker - add lat/long
        if (layer instanceof L.Marker || layer instanceof L.CircleMarker) {
            return strLatLng(layer.getLatLng());
        // Circle - lat/long, radius
        } else if (layer instanceof L.Circle) {
            var center = layer.getLatLng(),
                radius = layer.getRadius();
            return "Centro: "+strLatLng(center)+"<br />"
                  +"Radio: "+_round(radius, 2)+" m";
        // Rectangle/Polygon - area
        } else if (layer instanceof L.Polygon) {
            var latlngs = layer._defaultShape ? layer._defaultShape() : layer.getLatLngs(),
                area = L.GeometryUtil.geodesicArea(latlngs);
            return "Área: "+L.GeometryUtil.readableArea(area, true);
        // Polyline - distance
        } else if (layer instanceof L.Polyline) {
            var latlngs = layer._defaultShape ? layer._defaultShape() : layer.getLatLngs(),
                distance = 0;
            if (latlngs.length < 2) {
                return "Distancia: N/A";
            } else {
                for (var i = 0; i < latlngs.length-1; i++) {
                    distance += latlngs[i].distanceTo(latlngs[i+1]);
                }
                return "Distancia: "+_round(distance, 2)+" m";
            }
        }
        return null;
    };

    // Object created - bind popup to layer, add to feature group
    map.on(L.Draw.Event.CREATED, function(event) {
        var layer = event.layer;
        var content = getPopupContent(layer);
        if (content !== null) {
            layer.bindPopup(content);
        }
        drawnItems.addLayer(layer);
    });

    // Object(s) edited - update popups
    map.on(L.Draw.Event.EDITED, function(event) {
        var layers = event.layers,
            content = null;
        layers.eachLayer(function(layer) {
            content = getPopupContent(layer);
            if (content !== null) {
                layer.setPopupContent(content);
            }
        });
    });
//=====================================================================

// Creating window object
var marker_1 = L.marker([29,-110],{icon:firefoxIcon,title:"Click to show window." }).addTo(map);

    marker_1.on('click',function(){

        var win =  L.control.window(map,{title:'EVENTO',maxWidth:400,modal: true})
                .content('<div ><select><option>Tropicales</option><option>Extratropicales</option></select></div>')
               
                .show()
    });
//=================================================================================
//STYLED CONTROL
          

        var baseTree = [
            
            {
                label: 'Evento',
                children: [
                    {label: 'Katia',layer: eventoAnimacion},                 		  
                 		   ]
                 		}               
            ,
            {
                label: 'Trayectoria',
                children: [
                    {label: 'Katia', layer: eventoTrayectoria},
                ]
            },
            {
                label: 'Video',
                children: [
                    {label: 'Katia', layer: videoOverlay},
                ]
            },
            {
                label: 'Metadato',
                children: [
                    {label: 'Katia', layer: marker},
                ]
            },
            {
                label: 'Limites',
                children: [
                    {label: 'Costa', layer: costa, name: 'Costa'},    
                ]
            },
        ];

     var lay =   L.control.layers.tree(baseLayers,baseTree,
     	{               
            }).addTo(map);
lay.addTo(map).collapseTree().expandSelected().collapseTree(true);
        L.DomEvent.on(L.DomUtil.get('onlysel'), 'click', function() {
            lay.collapseTree(true).expandSelected(true);
        });



//=================================================================================
//STYLED CONTROL



            }







        window.addEventListener('load', function () {
            initMap();
        });
}(window));

