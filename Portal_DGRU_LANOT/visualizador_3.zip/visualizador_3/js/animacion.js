// example.js

//var t = [0,1.,2.,3.,4.,5.];
//var t = ' 2006-1-1 00:00:00,2006-1-3 01:00:00,2006-1-6 00:00:00'
//var t ='2006-01/2007-01/P1M'

//var eventoAnimacion = L.layerGroup();
//var eventoTrayectoria = L.layerGroup();
(function (window) {'use strict';
    function initMap() {
        var control;
        var L = window.L;

        var map = L.map('map', {
            zoom: 5,
            zoominfoControl: true,
            zoomControl: false,
            fullscreenControl: true,
            fullscreenControlOptions: {
            position: 'topleft'
            },
            loadingControl: true,
            loadingControlOptions: {
            position: 'bottomleft'
            },
            timeDimension: true,
            timeDimensionOptions:{
                //times : t,
                timeInterval: "2017-09-05 00:00:00/2017-09-09 00:00:00",
                period: "PT1H",
            },
            timeDimensionControl: true,
            timeDimensionControlOptions:{
                position: "bottomleft",
                autoPlay: true,       
                loopButton: true,
                limitSliders: true,
                timeSliderDragUpdate: true,
                playReverseButton: true,
                playerOptions: {            
                    loop: true,
                    transitionTime:1000,
                }       
                //timeSteps: 1,
            },    
            center: [19.9,-99.0],
            //layers: [mbGrayscale,eventoAnimacion]
        });

        /*
        L.control.zoom({
            position: 'topleft'
        }).addTo(map);
        */

        L.control.zoomBox({
        modal: true,
        title: "Box area zoom"
        }).addTo(map);

        L.control.navbar().addTo(map);

        /*
        var miniMap = new L.Control.GlobeMiniMap({     
          land:'#FFFFFF',
          water:'#1fa4f1',
          marker:'#000000',
          topojsonSrc: 'data/world.json'
        }).addTo(map);
        */

        // TILES LAYERS
        var mbAttr = 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors,<a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>,Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
            mbUrl = 'https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token=pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpejY4NXVycTA2emYycXBndHRqcmZ3N3gifQ.rJcFIG214AriISLbB6B5aw',
            
            esri_wiAttr = 'Tiles &copy; Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community',
            esri_wiUrl = 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',

            esri_OceanAttr = 'Tiles &copy; Esri &mdash; Sources: GEBCO, NOAA, CHS, OSU, UNH, CSUMB, National Geographic, DeLorme, NAVTEQ, and Esri',
            esri_OceanUrl = 'https://server.arcgisonline.com/ArcGIS/rest/services/Ocean_Basemap/MapServer/tile/{z}/{y}/{x}' ,

            openStreetMapAttr = '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
            openStreetMapUrl = 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',

            stamenTerrainAttr = 'Map tiles by <a href="http://stamen.com">Stamen Design</a>, <a href="http://creativecommons.org/licenses/by/3.0">CC BY 3.0</a> &mdash; Map data &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
            stamenTerrainUrl = 'https://stamen-tiles-{s}.a.ssl.fastly.net/terrain/{z}/{x}/{y}{r}.{ext}',

            cartoDB_DarkAttr = '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>',
            cartoDB_DarkUrl = 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png',

            nasaGIBS_ViirsAttr = 'Imagery provided by services from the Global Imagery Browse Services (GIBS), operated by the NASA/GSFC/Earth Science Data and Information System (<a href="https://earthdata.nasa.gov">ESDIS</a>) with funding provided by NASA/HQ.',
            nasaGIBS_ViirsUrl = 'https://map1.vis.earthdata.nasa.gov/wmts-webmerc/VIIRS_CityLights_2012/default/{time}/{tilematrixset}{maxZoom}/{z}/{y}/{x}.{format}';


        var mbGrayscale   = L.tileLayer(mbUrl, {id: 'mapbox.light', attribution: mbAttr,edgeBufferTiles: 1}),
            mbStreets  = L.tileLayer(mbUrl, {id: 'mapbox.streets',   attribution: mbAttr,edgeBufferTiles: 1}),
            esri_wi  = L.tileLayer(esri_wiUrl, {attribution: esri_wiAttr,edgeBufferTiles: 1}),
            esri_Ocean  = L.tileLayer(esri_OceanUrl, {attribution: esri_OceanAttr,edgeBufferTiles: 1}),
            openStreetMap = L.tileLayer(openStreetMapUrl, {attribution: openStreetMapAttr,edgeBufferTiles: 1}),
            stamenTerrain = L.tileLayer(stamenTerrainUrl, {subdomains:'abcd',ext:'png',attribution: stamenTerrainAttr,edgeBufferTiles: 1}),
            cartoDB_Dark = L.tileLayer(cartoDB_DarkUrl, {subdomains:'abcd',attribution: cartoDB_DarkAttr,edgeBufferTiles: 1}),
            nasaGIBS_Viirs = L.tileLayer(nasaGIBS_ViirsUrl, {bounds: [[-85.0511287776, -179.999999975], [85.0511287776, 179.999999975]],minZoom: 1,maxZoom: 8,format: 'jpg',time: '',tilematrixset: 'GoogleMapsCompatible_Level',edgeBufferTiles: 1});

        var basemaps = [
        esri_wi,
        mbStreets,
        mbGrayscale,
        esri_Ocean,
        openStreetMap,
        //stamenTerrain,
        //cartoDB_Dark,
        nasaGIBS_Viirs,
        ];

        // Basemaps control
        var controlBase = L.control.basemaps({
            position : 'bottomleft',
            basemaps: basemaps,
            tileX: 0,  // tile X coordinate
            tileY: 0,  // tile Y coordinate
            tileZ: 1   // tile zoom level
        }).addTo(map);

        
        // coordenadas 
        L.control.coordinates({
            position:"bottomright",
            decimals:2,
            decimalSeperator:",",
            labelTemplateLat:"Latitud: {y}",
            labelTemplateLng:"Longitud: {x}"
        }).addTo(map);

        // escala
        L.control.scale({
            position: 'bottomright'
        }).addTo(map);


        var proxy = 'server/proxy.php';
        var testWMS = "http://132.247.103.145:8080/geoserver/wms?SERVICE=WMS&"

        var testLayer = L.tileLayer.wms(testWMS, {
            layers: 'cite:katia',
            format: 'image/png',
            transparent: true,
            //attribution: '<a href="https://www.pik-potsdam.de/">PIK</a>'
        });

        var eventoTrayectoria  = L.tileLayer.wms(testWMS, {
            layers: 'cite:katia_trayectoria ',
            format: 'image/png',
            transparent: true,
            //attribution: '<a href="https://www.pik-potsdam.de/">PIK</a>'
        });

        var costa = L.tileLayer.wms(testWMS, {
            layers: 'cite:coastline_G16 ',
            format: 'image/png',
            transparent: true,
            //attribution: '<a href="https://www.pik-potsdam.de/">PIK</a>'
        });

        var eventoAnimacion = L.timeDimension.layer.wms(testLayer,{updateTimeDimension: true}, {proxy: proxy});
        eventoAnimacion.addTo(map);

        //var eventoTrayectoria = L.timeDimension.layer.wms(testLayer_tra,{updateTimeDimension: true}, {proxy: proxy});
        //eventoTrayectoria.on('mouseover', function () {
          //  this.setText('  ►  ', {repeat: true, attributes: {fill: 'red'}});
        //});

        //eventoTrayectoria.on('mouseout', function () {
          //  this.setText(null);
        //});

        eventoTrayectoria.addTo(map);

        costa.addTo(map)
        /*
        var testLegend = L.control({
            position: 'topright'
        });
        testLegend.onAdd = function(map) {
            var src = testWMS + "?SERVICE=WMS&VERSION=1.3.0&REQUEST=GetLegendGraphic&LAYER=tmp&PALETTE=tmp";
            var div = L.DomUtil.create('div', 'info legend');
            div.innerHTML +=
                '<img src="' + src + '" alt="legend">';
            return div;
        };
        testLegend.addTo(map);
        */

        var logo= L.control({position : 'topright'});

        logo.onAdd = function(map) {
            this._div = L.DomUtil.create('div', 'myControl');
            var img_log = "<div><img src=\"data/imagenes/logos/lanot_logo_b.png\"></img></div>";

            this._div.innerHTML = img_log;
            return this._div;

        }
        logo.addTo(map);

        var miniMap = new L.Control.MiniMap(mbStreets, { toggleDisplay: true ,minimized: false, position:'bottomright'}).addTo(map);



        var layers = {"Evento":{
                "Katia": eventoAnimacion},
                "Trayectoria":{
                "Trayectoria Katia": eventoTrayectoria},
                "Limites":{
                "Costa": costa}
        };

        var baseLayers = {
            
        };

        // control de capas
        L.control.groupedLayers(baseLayers,layers,{
            position: 'topright'
        }).addTo(map);

        // rule
        L.control.ruler({
            position: 'topleft',
            circleMarker: {               // Leaflet circle marker options for points used in this plugin
                color: '#FFFFFF',
                radius: 2
            },
            lineStyle: {                  // Leaflet polyline options for lines used in this plugin
                color: '#1fa4f1',
                dashArray: '1,6'
            },
        }).addTo(map);

        // add layer
        var style = {
                    color: 'red',
                    opacity: 1.0,
                    fillOpacity: 1.0,
                    weight: 2,
                    clickable: false
                };
           
        L.Control.FileLayerLoad.LABEL = '<img class="icon" src="data/imagenes/iconos/folder.svg" alt="file icon"/>';
                control = L.Control.fileLayerLoad({
                    fitBounds: true,
                    layerOptions: {
                        style: style,
                        pointToLayer: function (data, latlng) {
                            return L.circleMarker(
                                latlng,
                                { style: style }
                            );
                        }
                    }
                });
                control.addTo(map);
                control.loader.on('data:loaded', function (e) {
                    var layer = e.layer;
                    console.log(layer);
                });
            

        // create the geocoding control and add it to the map
        var searchControl = L.esri.Geocoding.geosearch().addTo(map);

        // create an empty layer group to store the results and add it to the map
        var results = L.layerGroup().addTo(map);

        // listen for the results event and add every result to the map
        searchControl.on("results", function(data) {
            results.clearLayers();
            for (var i = data.results.length - 1; i >= 0; i--) {
                results.addLayer(L.marker(data.results[i].latlng));
            }
        });


        var sidebar = L.control.sidebar('sidebar', {
                    closeButton: true,
                    position: 'left'
                });
                map.addControl(sidebar);

                /*setTimeout(function () {
                    sidebar.show();
                }, 500);*/

                var popup = L.responsivePopup().setContent('KATIA');
                var marker = L.marker([20.061111,-97.688611]).addTo(map).bindPopup(popup).on('click', function () {
                    sidebar.toggle();
                });

                map.on('click', function () {
                    sidebar.hide();
                })

                sidebar.on('show', function () {
                    console.log('Sidebar will be visible.');
                });

                sidebar.on('shown', function () {
                    console.log('Sidebar is visible.');
                });

                sidebar.on('hide', function () {
                    console.log('Sidebar will be hidden.');
                });

                sidebar.on('hidden', function () {
                    console.log('Sidebar is hidden.');
                });

                L.DomEvent.on(sidebar.getCloseButton(), 'click', function () {
                    console.log('Close button clicked.');
                });

            }

        window.addEventListener('load', function () {
            initMap();
        });
}(window));

